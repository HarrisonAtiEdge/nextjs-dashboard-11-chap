const CHUNK_PUBLIC_PATH = "server/app/seed/route.js";
const runtime = require("../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules__pnpm_bc7e4a._.js");
runtime.loadChunk("server/chunks/[root of the server]__32906d._.js");
runtime.loadChunk("server/chunks/_70c560._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/seed/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/.pnpm/next@15.0.2_e4kbeb3oepbyvs7ql5y74riunu/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/seed/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
