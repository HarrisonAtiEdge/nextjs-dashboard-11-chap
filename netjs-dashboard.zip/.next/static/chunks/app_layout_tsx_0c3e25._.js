(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_0c3e25._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_0c3e25._.js",
  "chunks": [
    "static/chunks/[root of the server]__8c8e75._.css",
    "static/chunks/_61e504._.js"
  ],
  "source": "dynamic"
});
