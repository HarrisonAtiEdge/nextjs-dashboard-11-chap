(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_(overview)_page_tsx_f7ed56._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_(overview)_page_tsx_f7ed56._.js",
  "chunks": [
    "static/chunks/_802e61._.js"
  ],
  "source": "dynamic"
});
