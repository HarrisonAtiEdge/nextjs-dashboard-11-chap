(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/4836d_next_dist_compiled_react-dom-experimental_e19d1c._.js",
    "static/chunks/4836d_next_dist_compiled_232f02._.js",
    "static/chunks/4836d_next_dist_client_62aaca._.js",
    "static/chunks/4836d_next_dist_9fe762._.js",
    "static/chunks/90823_@swc_helpers_cjs_6ab2e1._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_107bef._.js"
  ],
  "source": "entry"
});
