(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_invoices_page_tsx_f7a727._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_invoices_page_tsx_f7a727._.js",
  "chunks": [
    "static/chunks/_32d243._.js"
  ],
  "source": "dynamic"
});
