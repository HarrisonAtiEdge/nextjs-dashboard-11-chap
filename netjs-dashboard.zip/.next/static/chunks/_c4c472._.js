(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_c4c472._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_c4c472._.js",
  "chunks": [
    "static/chunks/7e1fa_next_dist_compiled_react-dom_4e857e._.js",
    "static/chunks/7e1fa_next_dist_compiled_b1d475._.js",
    "static/chunks/7e1fa_next_dist_client_117977._.js",
    "static/chunks/7e1fa_next_dist_da30fa._.js",
    "static/chunks/90823_@swc_helpers_cjs_6ab2e1._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_43a03a._.js"
  ],
  "source": "entry"
});
