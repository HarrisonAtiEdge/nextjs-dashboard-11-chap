(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_layout_tsx_364b17._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_layout_tsx_364b17._.js",
  "chunks": [
    "static/chunks/_522cce._.js"
  ],
  "source": "dynamic"
});
