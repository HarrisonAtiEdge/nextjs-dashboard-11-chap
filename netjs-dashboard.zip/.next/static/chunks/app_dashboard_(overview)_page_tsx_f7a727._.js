(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_(overview)_page_tsx_f7a727._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_(overview)_page_tsx_f7a727._.js",
  "chunks": [
    "static/chunks/4836d_next_dist_375cd7._.js",
    "static/chunks/app_dashboard_(overview)_page_tsx_31276a._.js"
  ],
  "source": "dynamic"
});
