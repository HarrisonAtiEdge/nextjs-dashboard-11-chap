(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_4f08fe._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_4f08fe._.js",
  "chunks": [
    "static/chunks/_b209f9._.js"
  ],
  "source": "dynamic"
});
