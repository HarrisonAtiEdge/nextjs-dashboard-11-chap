__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__66b4a9._.js",
  "static/chunks/251fc_react-dom_133f80._.js",
  "static/chunks/node_modules__pnpm_4744b4._.js",
  "static/chunks/[root of the server]__f265a1._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_b6a8c9._.js"
])
